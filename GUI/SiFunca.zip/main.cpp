#include <SFML/Graphics.hpp>
#include "buttons.h"
#include "MainMenu.h"

using namespace sf;

/* int main(){

    MainMenu * partida1;
    partida1 = new MainMenu(400,400,"Hola");

    return 0;   
} */

int main(){
    RenderWindow MENU(VideoMode(960,720),"Main Menu",Style::Default);
    MainMenu MainMenu(MENU.getSize().x , MENU.getSize().y );

    while (MENU.isOpen()){
        Event event;
        while (MENU.pollEvent(event)){
            if(event.type == Event::Closed) MENU.close(); 
            if(event.type == Event::KeyReleased) {
                if(event.key.code == Keyboard::Up){
                    MainMenu.MoveUp();
                    break;
                }
                if(event.key.code == Keyboard::Down){
                    MainMenu.MoveDown();
                    break;
                }
                if(event.key.code == Keyboard::Return){
                    RenderWindow PLAY(VideoMode(960,720),"PLAY");
                    RenderWindow OPTIONS(VideoMode(960,720),"OPTIONS");
                    RenderWindow ABOUT(VideoMode(960,720),"ABOUT");
                    
                    int x = MainMenu.MainMenuPressed();
                    if( x==0){
                        while (PLAY.isOpen()){
                            Event playEvent;

                            while (PLAY.pollEvent(playEvent)){
                                if(playEvent.type == Event::Closed) PLAY.close(); 
                                if(playEvent.type == Event::KeyPressed){
                                    if(playEvent.key.code == Keyboard::Escape){
                                        PLAY.close();
                                    }
                                }
                            }
                            OPTIONS.close();
                            ABOUT.close();
                            OPTIONS.close();
                            PLAY.clear();
                            PLAY.display();
                        }                        
                    }
                    if( x==1){
                        while (OPTIONS.isOpen()){
                            Event optionsEvent;

                            while (OPTIONS.pollEvent(optionsEvent)){
                                if(optionsEvent.type == Event::Closed) OPTIONS.close(); 
                                if(optionsEvent.type == Event::KeyPressed){
                                    if(optionsEvent.key.code == Keyboard::Escape){
                                        OPTIONS.close();
                                    }
                                }
                            }
                            PLAY.close();
                            OPTIONS.clear();
                            ABOUT.close();

                            OPTIONS.display();
                        }                        
                    }
                    if( x==2){
                        while (ABOUT.isOpen()){
                            Event aboutEVENT;

                            while (ABOUT.pollEvent(aboutEVENT)){
                                if(aboutEVENT.type == Event::Closed) ABOUT.close(); 
                                if(aboutEVENT.type == Event::KeyPressed){
                                    if(aboutEVENT.key.code == Keyboard::Escape){
                                        ABOUT.close();
                                    }
                                }
                            }
                            PLAY.close();
                            OPTIONS.clear();
                            ABOUT.clear();
                            ABOUT.display();
                        }                        
                    }
                    if( x== 3) MENU.close();
                    break;
                }
            }
        }
        MENU.clear();
        MainMenu.draw(MENU);
        MENU.display();
        
    }
    
}

