#include "mainwindow.h"
#include "./ui_mainwindow.h"
//#include "block.h"
#include "blockChain.h"

//#include "blockchain.h"
#include <chrono>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
//#include "stdafx.h"
#include <iostream>
#include <fstream>
using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void newTest(BlockChain &cadena, string fila,string &hash, string &hash_prev, string &node )
{
    //insercion de data de un bloque

    //cout << "Ingrese la informacion por filas separadas por comas...\n";
    int n_f = 4;
    int count = 0;
    vector<DataD*> data(n_f);
    //string fila;
    while (count!=n_f)
    {
        //cin>>fila;
        int n_words = 1;
        for (auto i : fila)
        {
            if (i == ',')
                n_words++;
        }
        vector<string> fila_to_b(n_words);
        string temp = "";
        int pos = 0;
        for (auto i : fila)
        {
            if (i == ',')
            {

                fila_to_b[pos] = temp;
                pos++;
                temp = "";
            }
            else if(i == fila[fila.size()-1]){
                fila_to_b[pos] = temp;
             }
            else
            {
                temp += i;
            }
        }
        DataD* dt = new DataD(fila_to_b);
        data[count] = dt;
        count++;
    }
//    string hash;
//    string hash_prev;
    cadena.insert_block(data,hash,hash_prev,node);
}


//ingresar todo
void MainWindow::on_pushButton_clicked()
{
//suama mas 2

//    QString valor=ui->dato->text();
//    int entero=valor.toInt();
//    ui->resultado->setText("sale");
    QString dato=ui->dato->text();
    string pasar_dato=dato.toStdString();
    BlockChain cadena = BlockChain();
    string H;
    string hp;
    string node;
    //validar entrada
    newTest(cadena,pasar_dato,H,hp,node);


    QString h_q = QString::fromUtf8(H.c_str());
    QString node_qs = QString::fromUtf8(node.c_str());

    QString hp_q = QString::fromUtf8(hp.c_str());
    ui->hash->setText(h_q);
    ui->hash_prev->setText(hp_q);
    ui->nonce->setText(node_qs);
    int block=1;
    QString block_string=block_string.number(block);
    ui->n_bloque->setText(block_string);


    cout<<"hola"<<endl;


    QString dato_3=ui->dato_3->text();
    string pasar_dato_3=dato_3.toStdString();
    BlockChain cadena_3 = BlockChain();
    string H_3;
    string hp_3;
    string node_3;
    //validar entrada
    newTest(cadena_3,pasar_dato_3,H_3,hp_3,node_3);


    QString h_q_3 = QString::fromUtf8(H.c_str());
    QString node_qs_3 = QString::fromUtf8(node_3.c_str());

    QString hp_3_q = QString::fromUtf8(hp_3.c_str());
    ui->hash_3->setText(h_q);
    ui->hash_prev_3->setText(hp_3_q);
    ui->nonce_3->setText(node_qs_3);
    int block_3=1;
    QString block_string_3=block_string.number(block);
    ui->n_bloque_3->setText(block_string);



    QString dato_2=ui->dato_2->text();
    string pasar_dato_2=dato_2.toStdString();
    BlockChain cadena_2 = BlockChain();
    string H_2;
    string hp_2;
    string node_2;
    //validar entrada
    newTest(cadena_2,pasar_dato_2,H_2,hp_2,node_2);


    QString h_q_2 = QString::fromUtf8(H_2.c_str());
    QString node_qs_2 = QString::fromUtf8(node_2.c_str());

    QString hp_q_2 = QString::fromUtf8(hp_2.c_str());
    ui->hash_2->setText(h_q_2);
    ui->hash_prev_2->setText(hp_q_2);
    ui->nonce_2->setText(node_qs_2);
    int block_2=2;
    QString block_string_2=block_string.number(block_2);
    ui->n_bloque_2->setText(block_string_2);

















    QString dato_4=ui->dato_4->text();
    string pasar_dato_4=dato_4.toStdString();
    BlockChain cadena_4 = BlockChain();
    string H_4;
    string hp_4;
    string node_4;
    //validar entrada
    newTest(cadena_4,pasar_dato_4,H_4,hp_4,node_4);


    QString h_q_4 = QString::fromUtf8(H_4.c_str());
    QString node_qs_4 = QString::fromUtf8(node_4.c_str());

    QString hp_q_4 = QString::fromUtf8(hp_4.c_str());
    ui->hash_4->setText(h_q_4);
    ui->hash_prev_4->setText(hp_q_4);
    ui->nonce_4->setText(node_qs_4);
    int block_4=4;
    QString block_string_4=block_string.number(block_4);
    ui->n_bloque_4->setText(block_string_4);


}

